// A storage for online sessions
// Used in /definitions/auth.js
MAIN.sessions = {};