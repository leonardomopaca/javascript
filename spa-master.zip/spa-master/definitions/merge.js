// Styles
MERGE('/css/default.css', '/css/ui.css', '/css/default.css');

// Scripts
MERGE('/js/default.js', '/js/ui.js', '/js/default.js');
